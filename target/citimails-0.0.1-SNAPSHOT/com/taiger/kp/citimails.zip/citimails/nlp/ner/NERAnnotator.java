package com.taiger.kp.citimails.nlp.ner;

import java.util.ArrayList;
import java.util.List;

import com.taiger.kp.citimails.model.Document;
import com.taiger.kp.citimails.model.Sentence;

public class NERAnnotator {
	
	private List<NER> ner;
	
	public NERAnnotator () {
		
		ner = new ArrayList<>();
		
		ner.add(new OrganizationFinderNER());
		ner.add(new PersonFinderNER());
		ner.add(new DateFinderNER());
		ner.add(new TimeFinderNER());
		ner.add(new PercentageFinderNER());
		ner.add(new MoneyFinderNER());
		ner.add(new ISINFinderNER());
		ner.add(new CUSIPFinderNER());
		ner.add(new CorrectorNER());
		
	}
	
	public Document annotate (Document document) {
		
		List<Sentence> sentences = document.getContent();
		
		ner.forEach(n -> sentences.forEach(n::annotate));
		
		return document;
	}
	
}
