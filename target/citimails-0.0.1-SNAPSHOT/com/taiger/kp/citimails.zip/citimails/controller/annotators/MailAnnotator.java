package com.taiger.kp.citimails.controller.annotators;

public class MailAnnotator {

}
